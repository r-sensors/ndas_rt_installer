#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 192
#define NN_MNK_M 6400
#define NN_MNK_N 57600
#define NN_MNK_MN 40960
#define NN_MNK_K 36864
#define NN_MNK_GE 13824
#define NT_MNK_M 14400
#define NT_MNK_N 36864
#define NT_MNK_MN 40960
#define NT_MNK_K 141376
#define NT_MNK_GE 13824
#define TN_MNK_M 57600
#define TN_MNK_N 238144
#define TN_MNK_MN 40960
#define TN_MNK_K 14400
#define TN_MNK_GE 27000
#define TT_MNK_M 238144
#define TT_MNK_N 57600
#define TT_MNK_MN 40960
#define TT_MNK_K 238144
#define TT_MNK_GE 13824
#define C2R_K 1116

#endif
