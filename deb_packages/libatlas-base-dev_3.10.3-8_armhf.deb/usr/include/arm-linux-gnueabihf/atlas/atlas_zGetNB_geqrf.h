#ifndef ATL_zGetNB_geqrf

/*
 * NB selection for GEQRF: Side='RIGHT', Uplo='UPPER'
 * M : 25,192,448,960
 * N : 25,192,448,960
 * NB : 4,8,16,16
 */
#define ATL_zGetNB_geqrf(n_, nb_) \
{ \
   if ((n_) < 108) (nb_) = 4; \
   else if ((n_) < 320) (nb_) = 8; \
   else (nb_) = 16; \
}


#endif    /* end ifndef ATL_zGetNB_geqrf */
