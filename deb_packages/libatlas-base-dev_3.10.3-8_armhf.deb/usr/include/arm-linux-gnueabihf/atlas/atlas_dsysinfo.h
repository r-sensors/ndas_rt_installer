#ifndef ATL_DSYSINFO_H
   #define ATL_DSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 16384
#define ATL_fplat  3
#define ATL_lbnreg 128
#define ATL_mmnreg 64
#define ATL_nkflop 1037716

#endif
