#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 240
#define NN_MNK_M 8000
#define NN_MNK_N 224720
#define NN_MNK_MN 64000
#define NN_MNK_K 176720
#define NN_MNK_GE 54872
#define NT_MNK_M 8000
#define NT_MNK_N 18000
#define NT_MNK_MN 64000
#define NT_MNK_K 115520
#define NT_MNK_GE 54872
#define TN_MNK_M 392000
#define TN_MNK_N 392000
#define TN_MNK_MN 243200
#define TN_MNK_K 18000
#define TN_MNK_GE 148877
#define TT_MNK_M 176720
#define TT_MNK_N 8000
#define TT_MNK_MN 64000
#define TT_MNK_K 72000
#define TT_MNK_GE 54872
#define C2R_K 2147483647

#endif
